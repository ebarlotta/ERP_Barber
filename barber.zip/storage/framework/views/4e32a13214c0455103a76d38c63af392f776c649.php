<div>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Relacionar Usuarios a distintos Módulos <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	 <?php $__env->slot('header', null, []); ?> 
		<div class="flex">
			<!-- //Comienza en submenu de encabezado -->

			<!-- Navigation Links -->
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('submenu')->html();
} elseif ($_instance->childHasBeenRendered('ioYBJnY')) {
    $componentId = $_instance->getRenderedChildComponentId('ioYBJnY');
    $componentTag = $_instance->getRenderedChildComponentTagName('ioYBJnY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ioYBJnY');
} else {
    $response = \Livewire\Livewire::mount('submenu');
    $html = $response->html();
    $_instance->logRenderedChild('ioYBJnY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>

	 <?php $__env->endSlot(); ?>

	<div class="content-center flex">
		<div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
			<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
				<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
					<?php if(session()->has('message')): ?>
						<div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
							<div class="flex">
								<div>
									<p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<?php if($seleccionado): ?>
					<div class="text-left">
						<button wire:click="mostrarmodal()"	class="bg-green-300 hover:bg-green-400 text-white-900 font-bold py-2 px-4 rounded">
							Relacionar nuevo Usuario
						</button>
					</div>
					<?php endif; ?>
				</div>
				<?php if($isModalOpen): ?>
					<?php echo $__env->make('livewire.modulo-usuarios.createmodulousuarios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>	
				<?php if($datos): ?>
				<div class="flex">
					<div class="h-full" style="width: 40%">
						Módulos <br>
						<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li class="border text-left <?php if($seleccionado==$modulo->id): ?> bg-red-100 <?php endif; ?>" wire:click="CargarUsuarios(<?php echo e($modulo->id); ?>)">
									<div class="w-full p-3">
										<div class="flex rounded overflow-hidden border">
											<img class="block rounded-md flex-none bg-cover"	src="<?php echo e(asset('images/'. $modulo->imagen)); ?>" style="width:100px; height: 100px;">
											<div class="bg-white rounded-b pt-4 pl-4 flex flex-col justify-between leading-normal">
												<div class="text-black font-bold text-lg mb-2 leading-tight"><?php echo e($modulo->name); ?></div>
												<p class="text-grey-darker text-base">Read more</p>
											</div>
										</div>
									</div>
								</li>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="w-full"><?php echo e($datos->links()); ?></div>
					</div>
					<div style="width: 40%">
						<div class="bg-transparent">Usuarios</divbg-white>
						<?php if($usuariosdelmodulo): ?>
						<?php $__currentLoopData = $usuariosdelmodulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li class="border text-left bg-red-100 min-h-full">
									<div class="w-full p-3">
										<div class="flex rounded overflow-hidden border">
											<img class="block rounded-md flex-none bg-cover" src="https://picsum.photos/seed/picsum/80/80" style="width:100px; height: 100px;">
											<div class="bg-white rounded-b pt-4 pl-4 flex flex-col justify-between leading-normal">
												<div class="text-black font-bold text-lg mb-2 leading-tight"><?php echo e($usuario['name']); ?></div>
												<p class="text-grey-darker text-base">Read more and	more</p>
											</div>
											<div class="bg-white rounded-b p-4 flex flex-col justify-between leading-normal">
												<div class="text-black font-bold text-xl mb-2 leading-tight">
													<img class="block w-15 h-15 flex-none bg-cover"	src="<?php echo e(asset('images/activo.jpg')); ?>" width="40" height="40">
												</div>
											</div>
										</div>
									</div>
								</li>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<?php else: ?>
					<h1>No hay datos</h1>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/livewire/modulo-usuarios/modulo-usuarios-component.blade.php ENDPATH**/ ?>