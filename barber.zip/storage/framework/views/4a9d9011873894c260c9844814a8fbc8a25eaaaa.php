    <div class="bg-gray-400 ml-2 mr-4 text-center rounded-lg shadow-lg width: 99vw;">
        <h2 class="text-2xl font-bold mb-2 text-gray-800"><?php echo e($slot); ?></h2>
    </div>
<?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/components/tituloslim.blade.php ENDPATH**/ ?>