<div>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Gestión de Productos <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	 <?php $__env->slot('header', null, []); ?> 
		<div class="flex">
			<!-- //Comienza en submenu de encabezado -->

			<!-- Navigation Links -->
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('submenu')->html();
} elseif ($_instance->childHasBeenRendered('ownIAO2')) {
    $componentId = $_instance->getRenderedChildComponentId('ownIAO2');
    $componentTag = $_instance->getRenderedChildComponentTagName('ownIAO2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ownIAO2');
} else {
    $response = \Livewire\Livewire::mount('submenu');
    $html = $response->html();
    $_instance->logRenderedChild('ownIAO2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>

	 <?php $__env->endSlot(); ?>

	<div class="content-center flex">
		<div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
			<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
				<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
					<?php if(session()->has('message')): ?>
						<div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
							<div class="flex">
								<div>
									<p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<?php if($seleccionado): ?>
					<div class="text-left">
						<button wire:click="mostrarmodal()"	class="bg-green-300 hover:bg-green-400 text-white-900 font-bold py-2 px-4 rounded">
							Agregar Producto
						</button>
					</div>
					<?php endif; ?>
				</div>
				<?php if($isModalOpen): ?>
					<?php echo $__env->make('livewire.producto.createproductos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>	
				<?php if($productos): ?>
				<div class="flex">
					<div class="h-full" style="width: 40%">
						Productos <br>
						<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li class="border text-left" wire:click="CargarUsuarios(<?php echo e($producto->id); ?>)">
									<div class="w-full p-3">
										<div class="flex rounded overflow-hidden border">
											<img class="block rounded-md flex-none bg-cover" src="<?php echo e(asset('images/'. $producto->imagen)); ?>" style="width:100px; height: 100px;">
											<div class="bg-white rounded-b pt-4 pl-4 flex flex-col justify-between leading-normal">
												<div class="text-black font-bold text-lg mb-2 leading-tight"><?php echo e($producto->name); ?></div>
											</div>
										</div>
									</div>
								</li>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="w-full"><?php echo e($productos->links()); ?></div>
					</div>
				</div>
				<?php else: ?>
					<h1>No hay datos</h1>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/livewire//producto/producto-component.blade.php ENDPATH**/ ?>