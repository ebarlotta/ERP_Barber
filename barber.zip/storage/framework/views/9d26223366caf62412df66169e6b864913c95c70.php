	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Producto <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<div class="content-center flex">
		<div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
			<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
				
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.producto','data' => []]); ?>
<?php $component->withName('producto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
					<h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
						
						Titulo
				  </h3>
					<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
					<?php if(session()->has('message')): ?>
						<div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
							<div class="flex">
								<div>
									<p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>
				<?php if($productos ?? ''): ?>
				<div class="flex">
					<div class="h-full w-full">
						<div class="bg-white rounded-b pt-4 pl-4 flex justify-between leading-normal w-full">
							<div class="text-black font-bold text-lg mb-2 leading-tight w-36" style="width:35%;">Productos</div>
							<div class="text-black font-bold text-lg mb-2 leading-tight w-36 text-right">Existencia</div>
							<div class="text-black font-bold text-lg mb-2 leading-tight w-36 text-right">Stock Mínimo</div>
							<div class="text-black font-bold text-lg mb-2 leading-tight w-36 text-right">Estado</div>
							<div class="text-black font-bold text-lg mb-2 leading-tight w-36 text-right">Opciones</div>
						</div>

						<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li class="border text-left">
									<div class="w-full">
										<div class="flex rounded overflow-hidden border">
											<?php if($producto->ruta != 'sin_imagen.jpg'): ?> 
												<img class="block rounded-md flex-none bg-cover" src="<?php echo e(asset('images2/'.$producto->ruta)); ?>" style="width:80px; height: 80px;">	
											<?php else: ?>
												<img class="block rounded-md flex-none bg-cover" src="<?php echo e(asset('images/sin_imagen.jpg')); ?>" style="width:80px; height: 80px;">
											<?php endif; ?>
											<div class="bg-white rounded-b pt-4 pl-4 flex justify-between leading-normal w-full">
												<div class="text-black font-bold text-lg mb-2 leading-tight" style="width:25%;"><?php echo e($producto->name); ?></div>
												<div class="text-black text-lg mb-2 leading-tight w-1/6 w-auto"><?php echo e($producto->existencia); ?></div>
												<div class="text-black text-lg mb-2 leading-tight w-1/6"><?php echo e($producto->stock_minimo); ?></div>
												<div class="text-black text-lg mb-2 leading-tight w-1/6"><?php echo e($producto->estados_id); ?></div>
												<div class="text-black text-lg mb-2 leading-tight w-1/6">
                                          <div>
                                             <a href="<?php echo e(route('producto.edit', $producto->id)); ?>">
                                                <input class="btn btn-default" type="submit" value="Editar">
                                             </a>
                                          </div>
                                          <div>
															
                                          <form action='<?php echo e(route('producto.destroy',$producto->id)); ?>' method="post">
                                             <input class="btn btn-default" type="submit" value="Eliminar">
														
                                             <?php echo method_field('delete'); ?>
                                             <?php echo csrf_field(); ?>
                                          </form>
                                       </div>
                                    </div>
											</div>
										</div>
									</div>
								</li>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
				
				<?php else: ?>
				<h1>No hay datos</h1>
				<?php endif; ?>
			</div>
		</div>
	</div>



<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/producto/index.blade.php ENDPATH**/ ?>