<div class="text-left">
    <button wire:click="create()" class="bg-green-300 hover:bg-green-400 text-white-900 font-bold py-2 px-4 rounded">
        <?php echo e($slot); ?>

    </button>
</div><?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/components/crearproducto.blade.php ENDPATH**/ ?>