<div>
    
</div>
<?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/livewire/venta/venta-component.blade.php ENDPATH**/ ?>