	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Producto <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	<div class="content-center flex">
		<div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
			<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
				
				<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.producto','data' => []]); ?>
<?php $component->withName('producto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
					<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
					<?php if(session()->has('message')): ?>
						<div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3" role="alert">
							<div class="flex">
								<div>
									<p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>
				
				
					<div class="h-full w-full flex">
						
						<div class="w-1/2">
							<div class="max-w-sm rounded overflow-hidden shadow-lg justify-center">
								<?php if($producto->ruta != 'sin_imagen.jpg'): ?>
								<img class="w-full mt-4 ml-4" src="<?php echo e(asset('images2/' . $producto->ruta )); ?>" alt="Sunset in the mountains" style="width:200px; height:200px;">
								<?php else: ?>
								<img class="w-full mt-4 ml-4" src="<?php echo e(asset('images/sin_imagen.jpg' )); ?>" alt="Sunset in the mountains" style="width:200px; height:200px;">
								<?php endif; ?>
								<div class="px-6 py-4">
									<div class="font-bold text-xl mb-2"><?php echo e($producto->name); ?></div>
									<p class="text-gray-700 text-base">
										<?php echo e($producto->descripcion); ?>

									</p>
								</div>
								<div class="px-6 pt-4 pb-2">
									<?php if(count($tagsactivos)): ?>
										<?php $__currentLoopData = $tagsactivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagactivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"><?php echo e($tagactivo->name); ?>

											</span>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="w-1/2">
							<div class="max-w-sm rounded overflow-hidden shadow-lg h-full justify-around">
								<div class="px-6 py-4 align-middle h-1/2">
									<div class="font-bold text-xl mb-2">Agregados</div>
									<?php if(count($tagsactivos)): ?>
										<?php $__currentLoopData = $tagsactivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagactivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<a href="<?php echo e(route('producto.deltag',['product_id'=>$producto->id,'tag_id'=>$tagactivo->tag_id])); ?>">
											<span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">
												<?php echo e($tagactivo->name); ?>

											</span>
										</a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<p class="text-gray-700 text-base">
											Todavía no hay ninguna etiqueta agregada al producto
										</p>
									<?php endif; ?>
								</div>
								<div class="px-6 pt-4 pb-2 align-middle h-1/2">
									<div class="font-bold text-xl mb-2">Disponibles</div>
									<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<a href="<?php echo e(route('producto.addtag',['product_id'=>$producto->id,'tag_id'=>$tag->id])); ?>">
											<span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">
												<?php echo e($tag->name); ?>

											</span>
										</a>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
					</div>
				
			 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
				
				
			</div>
		</div>
	</div>



<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/producto/tagedit.blade.php ENDPATH**/ ?>