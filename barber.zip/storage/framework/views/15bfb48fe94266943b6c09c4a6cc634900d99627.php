<div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Relacionar Usuarios a Empresas <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex">
            <!-- //Comienza en submenu de encabezado -->

            <!-- Navigation Links -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('submenu')->html();
} elseif ($_instance->childHasBeenRendered('jvh5GTT')) {
    $componentId = $_instance->getRenderedChildComponentId('jvh5GTT');
    $componentTag = $_instance->getRenderedChildComponentTagName('jvh5GTT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jvh5GTT');
} else {
    $response = \Livewire\Livewire::mount('submenu');
    $html = $response->html();
    $_instance->logRenderedChild('jvh5GTT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

     <?php $__env->endSlot(); ?>

    <div class="content-center flex">
        <div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
                    <?php if(session()->has('message')): ?>
                        <div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3"
                            role="alert">
                            <div class="flex">
                                <div>
                                    <p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($seleccionado): ?>
                        <div class="text-left">
                            <button wire:click="mostrarmodal()"
                                class="bg-green-300 hover:bg-green-400 text-white-900 font-bold py-2 px-4 rounded">
                                Relacionar nuevo Usuario
                            </button>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if($isModalOpen): ?>
                    <?php echo $__env->make('livewire.empresa-usuarios.createempresausuarios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if($empresas): ?>
                    <div class="flex">
                        <div class="h-full" style="width: 40%">
                            Empresas
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul>
                                    <li class="align-bottom border px-4 py-2 text-left <?php if($seleccionado == $empresa->id): ?> bg-red-300 <?php endif; ?>"
                                        wire:click="CargarUsuarios(<?php echo e($empresa->id); ?>)">
                                        <div class="w-full p-3">
                                            <div class="flex rounded overflow-hidden border">
                                                <img class="block  flex-none bg-cover"
                                                    src="https://picsum.photos/seed/picsum/100/100"
                                                    style="width: 100px; height: 100px;">
                                                <div
                                                    class="bg-white rounded-b pl-4 flex flex-col justify-between leading-normal">
                                                    <div class="text-black  pt-4 font-bold text-lg mb-2 leading-tight">
                                                        <?php echo e($empresa->name); ?></div>
                                                    <p class="text-grey-darker text-base">Read more
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="w-full"><?php echo e($datos->links()); ?></div>
                        </div>
                        <div style="width: 40%">
                            <div class="bg-transparent">Usuarios</div>
                            <?php if($usuariosdelaempresa): ?>
                                <?php $__currentLoopData = $usuariosdelaempresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul>
                                        <li class="border px-4 py-2 text-left bg-red-300">
                                            <div class="w-full p-3">
                                                <div class="flex rounded overflow-hidden border">
                                                    <img class="block flex-none bg-cover"
                                                        src="https://picsum.photos/seed/picsum/80/80"
                                                        style="width: 100px; height: 100px;">
                                                    <div
                                                        class="bg-white rounded-b pl-4 pt-4 flex flex-col justify-between leading-normal">
                                                        <div class="text-black font-bold text-lg mb-2 leading-tight">
                                                            <?php echo e($usuario['name']); ?></div>
                                                        <p class="text-grey-darker text-base">Read more and
                                                            more</p>
                                                    </div>
                                                    
                                                    <div
                                                        class="bg-white rounded-b p-4 flex flex-col justify-between leading-normal">
                                                        <div class="text-black font-bold text-xl mb-2 leading-tight">
                                                            <img class="block w-15 h-15 flex-none bg-cover"
                                                                src="<?php echo e(asset('images/activo.jpg')); ?>" width="40"
                                                                height="40">
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <h1>No hay datos</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
=======
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.titulo','data' => []]); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Relacionar Usuarios a Empresas <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
	 <?php $__env->slot('header', null, []); ?> 
		<div class="flex">
			<!-- //Comienza en submenu de encabezado -->

			<!-- Navigation Links -->
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('submenu')->html();
} elseif ($_instance->childHasBeenRendered('oadklKN')) {
    $componentId = $_instance->getRenderedChildComponentId('oadklKN');
    $componentTag = $_instance->getRenderedChildComponentTagName('oadklKN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oadklKN');
} else {
    $response = \Livewire\Livewire::mount('submenu');
    $html = $response->html();
    $_instance->logRenderedChild('oadklKN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>

	 <?php $__env->endSlot(); ?>

	<div class="content-center flex">
		<div class="bg-white p-2 text-center rounded-lg shadow-lg w-full">
			<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
				<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg px-4 py-4">
					<?php if(session()->has('message')): ?>
						<div class="bg-teal-100 border-t-4 border-teal-500 rounded-b text-teal-900 px-4 py-3 shadow-md my-3"
							role="alert">
							<div class="flex">
								<div>
									<p class="text-xm bg-lightgreen"><?php echo e(session('message')); ?></p>
								</div>
							</div>
						</div>
					<?php endif; ?>
					
					<div class="text-left">
						<button wire:click="mostrarmodal()"
							class="bg-green-300 hover:bg-green-400 text-white-900 font-bold py-2 px-4 rounded">
							Relacionar nuevooooo
						</button>
					</div>
				</div>

				
				<?php if($isModalOpen): ?>
					<?php echo $__env->make('livewire.empresa-usuarios.createempresausuarios1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php if($empresas): ?>
					<table>
						<tr>
							<td>
								<table>
									<?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td class="border px-4 py-2 text-left" wire:click="CargarUsuarios(<?php echo e($empresa->id); ?>)">
												
												<div class="w-full p-3">
													<div class="flex rounded overflow-hidden border <?php if($seleccionado==$empresa->id): ?> bg-red-300 <?php endif; ?>">
														
														<?php echo e($seleccionado. " " . $empresa->id); ?>

														<img class="block w-15 h-15 flex-none bg-cover"
															src="https://picsum.photos/seed/picsum/100/100">
														<div
															class="bg-white rounded-b p-4 flex flex-col justify-between leading-normal">
															<div
																class="text-black font-bold text-xl mb-2 leading-tight">
																<?php echo e($empresa->name); ?></div>
															<p class="text-grey-darker text-base">Read more
															</p>
														</div>
													</div>
												</div>

											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							</td>
							<td>
								<table>
									<?php if($usuariosdelaempresa): ?>
										<?php $__currentLoopData = $usuariosdelaempresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td class="border px-4 py-2 text-left bg-red-300">
													<div class="w-full p-3">
														<div class="flex rounded overflow-hidden border">
															<img class="block w-15 h-15 flex-none bg-cover"
																src="https://picsum.photos/seed/picsum/80/80">
															<div
																class="bg-white rounded-b p-4 flex flex-col justify-between leading-normal">
																<div class="text-black font-bold text-xl mb-2 leading-tight"><?php echo e($usuario['name']); ?></div>
																<p class="text-grey-darker text-base">Read more</p>
															</div>
															
															<div
																class="bg-white rounded-b p-4 flex flex-col justify-between leading-normal">
																<div
																	class="text-black font-bold text-xl mb-2 leading-tight">
																	<img class="block w-15 h-15 flex-none bg-cover"
																		src="public/images/activo.jpg'">
																</div>
															</div>
															
														</div>
													</div>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</table>
							</td>
						</tr>
					</table>
				<?php else: ?>
					<h1>No hay datos</h1>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
>>>>>>> 71cf9addfa7dc992098f5a94d8517b79fe83507c
</div>
<?php /**PATH /home/usuario/Escritorio/Proyecto/barber/resources/views/livewire/empresa-usuarios/empresa-usuarios-component.blade.php ENDPATH**/ ?>