@extends('layouts.adminlte')

<div>
   <x-slot name="header">
   <x-titulo>Relacionar Usuarios a distintos Módulos</x-titulo>
      <div class="flex">
         <!-- //Comienza en submenu de encabezado -->
         
			<!-- Navigation Links -->
         no se
         <div class="box box-solid box-default">...</div>
			@livewire('submenu')
		</div>
      enlll
      <div>nada</div>
   </x-slot>
</div>




