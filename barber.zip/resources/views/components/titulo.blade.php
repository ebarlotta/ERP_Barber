    <div class="bg-gray-400 mr-4 p-2 text-center rounded-lg shadow-lg w-full">
        <h2 class="text-2xl font-bold mb-2 text-gray-800">{{ $slot }}</h2>
    </div>
