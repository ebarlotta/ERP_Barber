<?php

namespace Database\Factories;

use App\Models\InformeUsuario;
use Illuminate\Database\Eloquent\Factories\Factory;

class InformeUsuarioFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = InformeUsuario::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
