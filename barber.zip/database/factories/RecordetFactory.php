<?php

namespace Database\Factories;

use App\Models\Recordet;
use Illuminate\Database\Eloquent\Factories\Factory;

class RecordetFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Recordet::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
