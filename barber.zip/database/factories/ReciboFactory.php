<?php

namespace Database\Factories;

use App\Models\Recibo;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReciboFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Recibo::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
