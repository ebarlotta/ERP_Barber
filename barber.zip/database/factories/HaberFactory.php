<?php

namespace Database\Factories;

use App\Models\Haber;
use Illuminate\Database\Eloquent\Factories\Factory;

class HaberFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Haber::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
