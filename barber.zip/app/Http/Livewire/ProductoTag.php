<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ProductoTag extends Component
{
    public function render()
    {
        return view('livewire.producto-tag');
    }
}
